//#include "stm32f10x.h"
#include "cc.h"

typedef void (* sys_timeout_handler)(void *arg);

//sys_init() {}

//sys_timeouts_init(){}

//sys_mutex_lock(){}

//sys_mutex_unlock(){}

//sys_mutex_new(){}

//etharp_request(){}

tcp_active(){}	

//sys_arch_sem_wait(){}

//sys_sem_free(){}

//sys_sem_new(){ return 0;}

PER_STOP(){} 

//etharp_tmr(){}

sys_arch_mbox_fetch(){}

//ethernet_input(){}

//sys_mbox_new(){ return 0;}
//sys_mbox_post(){ return 0;}
//sys_thread_new(){}
//sys_mbox_trypost(){}
sys_mbox_valid(){ return 1;}
//sys_mbox_free(){}
sys_sem_valid(){}
sys_arch_mbox_tryfetch(){}
sys_mbox_set_invalid(){}
sys_sem_set_invalid(){}
//sys_sem_signal(){}

//sys_timeouts_init(void){}
//etharp_request(){}
//ip_route(){}
//pbuf_free(){}
//pbuf_ref(){}

//tcp_timer_needed(void){}
//current_iphdr_dest(){}
//current_iphdr_src(){}
//inet_chksum_pseudo(){}
//ip4_addr_isbroadcast(){}
//lwip_htons(){}
//lwip_ntohl(){}
//lwip_ntons(){}
//pbuf_cat(){}
//pbuf_clen(){}
//lwip_ntohs(){}
//pbuf_header(){}
//pbuf_realloc(){}
//ip_output(){}
//lwip_htonl(){}
//pbuf_alloc(){}
//etharp_tmr(){}
//tcpip_callback_with_block(){}

//void sys_timeout(u32_t msecs, sys_timeout_handler handler, void *arg){}





